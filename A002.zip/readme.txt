Bible SuperSearch Bible Export

Plain Text
Simple, plain text format


Index of Bibles Included: 

File                              Bible                                                                            Language
================================================================================================================================================================
* afri.txt ---------------------- Afrikaans 1953 (1953) ---------------------------------------------------------- Afrikaans
* albanian.txt ------------------ Albanian ----------------------------------------------------------------------- Shqip (Albanian)
* almeida_ra.txt ---------------- Tradução de João Ferreira de Almeida (Versão Revista e Atualizada) ------------- Português (Portuguese)
* almeida_rc.txt ---------------- Tradução de João Ferreira de Almeida Revista e Corrigida. ---------------------- Português (Portuguese)
* asv.txt ----------------------- American Standard Version (1901) ----------------------------------------------- English
* asvs.txt ---------------------- American Standard Version w Strong's ------------------------------------------- English
* bishops.txt ------------------- Bishops Bible (1568) ----------------------------------------------------------- English
* bkr.txt ----------------------- Bible Kralicka ----------------------------------------------------------------- čeština, český jazyk (Czech)
* blivre.txt -------------------- Biblia Livre ------------------------------------------------------------------- Português (Portuguese)
* bungo.txt --------------------- Bungo-yaku: Taisho-kaiyaku (NT) (1950), Meiji-yaku (OT) (1953) (1950/1953) ----- 日本語 (にほんご) (Japanese)
* cadman.txt -------------------- Vietnamese Cadman (1934) ------------------------------------------------------- Tiếng Việt (Vietnamese)
* chinese_union_simp.txt -------- Chinese Union (Simplified) ----------------------------------------------------- 中文 (Zhōngwén), 汉语, 漢語 (Chinese)
* chinese_union_simp_s.txt ------ Chinese Union Version 和合本 - Simplified with Strong's numbers 简体中文版连史特朗经文滙篇 ----- 中文 (Zhōngwén), 汉语, 漢語 (Chinese)
* chinese_union_trad.txt -------- Chinese Union (Traditional) ---------------------------------------------------- 中文 (Zhōngwén), 汉语, 漢語 (Chinese)
* chinese_union_trad_s.txt ------ Chinese Union Version 和合本 - Traditional with Strong's numbers 繁體中文版連史特朗經文滙篇 ---- 中文 (Zhōngwén), 汉语, 漢語 (Chinese)
* ckjv_sds.txt ------------------ 中文英皇钦定本上帝版 Chinese KJV (Simplified) Shang-Di 简体中文 ------------------------------ 中文 (Zhōngwén), 汉语, 漢語 (Chinese)
* ckjv_sdt.txt ------------------ 中文英皇欽定本上帝版 Chinese KJV (Traditional) Shang-Di 繁體中文 ----------------------------- 中文 (Zhōngwén), 汉语, 漢語 (Chinese)
* cornilescu.txt ---------------- Cornilescu --------------------------------------------------------------------- Română (Romanian)
* coverdale.txt ----------------- Coverdale Bible (1535) --------------------------------------------------------- English
* diodati.txt ------------------- Diodati (1649) ----------------------------------------------------------------- Italiano (Italian)
* elberfelder_1871.txt ---------- Elberfelder (1871) ------------------------------------------------------------- Deutsch (German)
* elberfelder_1905.txt ---------- Elberfelder (1905) ------------------------------------------------------------- Deutsch (German)
* epee.txt ---------------------- La Bible de l'Épée (2005) ------------------------------------------------------ Français (French)
* fidela.txt -------------------- Fidela Biblia în limba română (2011-2016) -------------------------------------- Română (Romanian)
* finn.txt ---------------------- Finnish 1776 (Finnish) (1776) -------------------------------------------------- Suomi (Finnish)
* geneva.txt -------------------- Geneva Bible (1587) ------------------------------------------------------------ English
* indo_tb.txt ------------------- Terjemahan Baru (1994) --------------------------------------------------------- Bahasa Indonesia (Indonesian)
* indo_tm.txt ------------------- Terjemahan Lama ---------------------------------------------------------------- Bahasa Indonesia (Indonesian)
* irv.txt ----------------------- Indian Revised Version (2017 / 2018) ------------------------------------------- हिन्दी, हिंदी (Hindi)
* karoli.txt -------------------- Karoli ------------------------------------------------------------------------- magyar (Hungarian)
* kjv.txt ----------------------- Authorized King James Version (1611 / 1769) ------------------------------------ English
* kjv_strongs.txt --------------- KJV with Strongs (1611 / 1769) ------------------------------------------------- English
* korean.txt -------------------- Korean ------------------------------------------------------------------------- 한국어 (Korean)
* kougo.txt --------------------- Kougo-yaku (1954/1955) --------------------------------------------------------- 日本語 (にほんご) (Japanese)
* luther.txt -------------------- Luther Bible (1545) (1545) ----------------------------------------------------- Deutsch (German)
* luther_1912.txt --------------- Luther Bible (1912) (1912) ----------------------------------------------------- Deutsch (German)
* maori.txt --------------------- Maori Bible -------------------------------------------------------------------- te reo Māori (Maori)
* martin.txt -------------------- Martin (1744) ------------------------------------------------------------------ Français (French)
* net.txt ----------------------- NET Bible® (1996-2016) --------------------------------------------------------- English
* opt.txt ----------------------- Old Persian Translation (1895) ------------------------------------------------- فارسی (Persian)
* oster.txt --------------------- Ostervald (1996) --------------------------------------------------------------- Français (French)
* pol_nbg.txt ------------------- NOWEJ BIBLII GDANSKIEJ (2012) -------------------------------------------------- Polski (Polish)
* pol_ubg.txt ------------------- Uwspółcześniona Biblia Gdańska (2017) ------------------------------------------ Polski (Polish)
* polbg.txt --------------------- Polska Biblia Gdanska (1881) --------------------------------------------------- Polski (Polish)
* rv_1858.txt ------------------- Reina Valera 1858 NT (1858) ---------------------------------------------------- Español (Spanish)
* rv_1909.txt ------------------- Reina Valera 1909 (1909) ------------------------------------------------------- Español (Spanish)
* rv_1909_strongs.txt ----------- Reina-Valera 1909 w/Strong's --------------------------------------------------- Español (Spanish)
* rvg.txt ----------------------- Reina Valera Gómez (2010) ------------------------------------------------------ Español (Spanish)
* rvg_2004.txt ------------------ Reina Valera Gómez (2004) (2004) ----------------------------------------------- Español (Spanish)
* sagradas.txt ------------------ Sagradas Escrituras (1569) ----------------------------------------------------- Español (Spanish)
* schlachter.txt ---------------- Schlachter Bibel (1951) -------------------------------------------------------- Deutsch (German)
* segond_1910.txt --------------- Louis Segond 1910 (1910) ------------------------------------------------------- Français (French)
* stve.txt ---------------------- Staten Vertaling --------------------------------------------------------------- Nederlands (Dutch)
* svd.txt ----------------------- Smith Van Dyke ----------------------------------------------------------------- العربية (Arabic)
* swahili.txt ------------------- Swahili NT --------------------------------------------------------------------- Kiswahili (Swahili)
* synodal.txt ------------------- Synodal (1876) ----------------------------------------------------------------- русский (Russian)
* tagab.txt --------------------- Tagalog Ang Biblia (1905) ------------------------------------------------------ Wikang Tagalog (Tagalog)
* thaikjv.txt ------------------- Thai KJV ----------------------------------------------------------------------- ไทย (Thai)
* tr.txt ------------------------ Textus Receptus NT (1550 / 1884) ----------------------------------------------- Κοινη  (Greek)
* trparsed.txt ------------------ Textus Receptus Parsed NT (1550 / 1884) ---------------------------------------- Κοινη  (Greek)
* turkish.txt ------------------- Turkish ------------------------------------------------------------------------ Türkçe (Turkish)
* tyndale.txt ------------------- Tyndale Bible ------------------------------------------------------------------ English
* web.txt ----------------------- World English Bible (2006) ----------------------------------------------------- English
* wlc.txt ----------------------- WLC ---------------------------------------------------------------------------- עברית (Hebrew)


